#ifndef DATA_H
#define DATA_H
#include <iostream>
using namespace std;
class data
{
public:
	
	data();
	data(const char * name, const char * pccId);
	data(const data& student);		//copy constructor: make current object a copy of "student"
	~data();						//destructor: release the dynamically allocated memory	

	void getName(char * name) const;
	void getPccId(char * pccId) const;
	float getGpa(void) const;

	void setName(const char * name);
	void setPccId(const char * pccId);
	void setGpa(float gpa);

	friend ostream& operator<< (ostream& out, const data& student);
	const data& operator=(const data& student);	//overload assignment operator

private:
	char * name;
	char * pccId;
	float gpa;
};

bool operator< (const data& d1, const data& d2);	//overload < on data objects
bool operator== (const data& d1, const data& d2);	//overload == on data objects

#endif