#include <iostream>
using namespace std;

#include "util.h"

void pause()
{
	char	ch;
	cout << endl << "Please press q followed by enter key to continue ..." << endl;
	cin >> ch;
}