#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>

#include <iostream>
using namespace std;
#include "data.h"
#include "util.h"
#include <vector>

data * studentArray[] = {
	new data("sarah", "G10"),
	new data("eric", "G20"),
	new data("william", "G30"),
	new data("angie", "G40")};
const int size = sizeof(studentArray)/sizeof(data*);
	
void useVector();
void releaseStudentArray();

int main()
{
	_CrtSetDbgFlag ( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );

	useVector();	
	releaseStudentArray();

	pause();
	return 0;
}

void useVector()
{
	vector<data*> students;
	int i;
	for(i=0; i<size; i++)
		students.push_back (studentArray[i]);

	cout << "\nA vector of students: " << endl;
	for(i=0; i<size; i++)
		cout << *(students[i]) << endl;				//[] was overloaded

	vector<data*>::iterator it;						//use iterator
	cout << "\nA vector of students using iterator: " << endl;
	for(it = students.begin(); it != students.end(); it++)
		//*it gives you the current element which is a pointer to data 
		//to get to data, we need to dereference *it to get to the data object
		cout << **it << endl;						

	students.clear ();

	cout << "\nAfter clear the contents of the vector: " << endl;
	
	for(it = students.begin(); it != students.end(); it++)
		cout << **it << endl;
	
}

void releaseStudentArray()
{
	int i;
	for(i=0; i<size; i++)
		delete studentArray[i];
}


