#ifndef UTIL_H
#define UTIL_H

void pause();

#endif